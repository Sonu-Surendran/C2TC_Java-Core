package interface2;

public class Main {
	
	public static void main(String[] args) {
		Animals donkey = new Animals("Donkey",2,56,4,34);
		donkey.eyes();
		donkey.teeths();
		donkey.lamb();
	}

}
