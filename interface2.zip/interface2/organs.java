package interface2;

public interface organs {
	
	 public void eyes();
	 public void teeths();
	 public void lamb();
	 public void iq();
	  

	}